describe('foo', function() {
    it ('should pass', function() {
        expect(1).toBe(1);
    });
});