/**
 * This model is the base for all other models in this application.
 */
Ext.define('ExecDashboard.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'ExecDashboard.model'
    }
});
